import { Link, NavLink, Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';
import Events from './pages/Events.jsx';
import EventDetail from './pages/EventDetail.jsx';
import EventForm from './pages/EventForm.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Auth from './pages/Auth.jsx';

// Route guard: redirect to login if not signed in, or home if the role is wrong
function Guard({ roles, children }) {
  const { user, ready } = useAuth();
  if (!ready) return null;
  if (!user) return <Navigate to="/login" />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" />;
  return children;
}

export default function App() {
  const { user, logout } = useAuth();
  const canHost = user && ['organizer', 'admin'].includes(user.role);
  return (
    <>
      <header className="bar">
        <Link to="/" className="brand">Porchlight</Link>
        <nav>
          <NavLink to="/" end>Events</NavLink>
          {user && <NavLink to="/dashboard">My events</NavLink>}
          {canHost && <NavLink to="/events/new">Host an event</NavLink>}
          {user ? (
            <button className="link" onClick={logout}>Log out ({user.name.split(' ')[0]}, {user.role})</button>
          ) : (
            <><NavLink to="/login">Log in</NavLink><NavLink to="/register">Sign up</NavLink></>
          )}
        </nav>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<Events />} />
          <Route path="/events/:id" element={<EventDetail />} />
          <Route path="/events/new" element={<Guard roles={['organizer', 'admin']}><EventForm /></Guard>} />
          <Route path="/events/:id/edit" element={<Guard roles={['organizer', 'admin']}><EventForm /></Guard>} />
          <Route path="/dashboard" element={<Guard><Dashboard /></Guard>} />
          <Route path="/login" element={<Auth mode="login" />} />
          <Route path="/register" element={<Auth mode="register" />} />
        </Routes>
      </main>
    </>
  );
}
