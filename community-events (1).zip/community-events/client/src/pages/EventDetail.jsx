import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { fmt } from './Events.jsx';

export default function EventDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const nav = useNavigate();
  const [ev, setEv] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api(`/events/${id}`).then(setEv).catch((e) => setError(e.message)); }, [id]);

  const act = async (fn) => { try { setError(''); await fn(); } catch (e) { setError(e.message); } };
  if (error && !ev) return <p className="error">{error}</p>;
  if (!ev) return <p className="muted">Loading…</p>;

  const going = user && ev.participants.some((p) => p._id === user.id);
  const manage = user && (user.role === 'admin' || ev.organizer._id === user.id);

  return (
    <article className="detail">
      <span className="tag">{ev.category}</span>
      <h1>{ev.title}</h1>
      <p className="muted">{fmt(ev.date)} · {ev.venue.name}{ev.venue.address && `, ${ev.venue.address}`}</p>
      <p>{ev.description}</p>
      <p className="muted">Hosted by {ev.organizer.name}</p>

      {error && <p className="error">{error}</p>}
      <div className="actions">
        {user ? (
          going
            ? <button className="ghost" onClick={() => act(async () => setEv(await api(`/events/${id}/leave`, { method: 'POST' })))}>Leave event</button>
            : <button onClick={() => act(async () => setEv(await api(`/events/${id}/join`, { method: 'POST' })))}>Join this event</button>
        ) : <Link to="/login" className="btn">Log in to join</Link>}
        {manage && <Link to={`/events/${id}/edit`} className="btn ghost">Edit</Link>}
        {manage && (
          <button className="danger" onClick={() => window.confirm('Delete this event?') && act(async () => { await api(`/events/${id}`, { method: 'DELETE' }); nav('/'); })}>
            Delete
          </button>
        )}
      </div>

      <h2>{ev.participants.length} of {ev.capacity} going</h2>
      {ev.participants.length === 0 ? <p className="empty">Nobody has joined yet. Be the first.</p>
        : <ul className="people">{ev.participants.map((p) => <li key={p._id}>{p.name}</li>)}</ul>}
    </article>
  );
}
