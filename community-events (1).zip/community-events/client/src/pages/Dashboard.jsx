import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { EventRow } from './Events.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [hosting, setHosting] = useState([]);
  const [joined, setJoined] = useState([]);

  useEffect(() => {
    api('/events/mine/joined').then(setJoined);
    if (user.role !== 'attendee') api('/events/mine/organized').then(setHosting);
  }, [user.role]);

  return (
    <>
      <h1>My events</h1>
      {user.role !== 'attendee' && (
        <>
          <h2>Hosting ({hosting.length})</h2>
          {hosting.length === 0 ? <p className="empty">You haven't hosted anything yet. Use "Host an event" above.</p>
            : <div className="list">{hosting.map((e) => <EventRow key={e._id} ev={e} />)}</div>}
        </>
      )}
      <h2>Going to ({joined.length})</h2>
      {joined.length === 0 ? <p className="empty">You haven't joined any events. Browse the Events page.</p>
        : <div className="list">{joined.map((e) => <EventRow key={e._id} ev={e} />)}</div>}
    </>
  );
}
