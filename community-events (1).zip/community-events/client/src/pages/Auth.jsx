import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext.jsx';

export default function Auth({ mode }) {
  const { login, register } = useAuth();
  const nav = useNavigate();
  const isReg = mode === 'register';
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'attendee' });
  const [error, setError] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    try { await (isReg ? register(f) : login(f)); nav('/'); } catch (err) { setError(err.message); }
  };

  return (
    <form className="form narrow" onSubmit={submit}>
      <h1>{isReg ? 'Create your account' : 'Welcome back'}</h1>
      {error && <p className="error">{error}</p>}
      {isReg && <label>Name<input required value={f.name} onChange={set('name')} /></label>}
      <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
      <label>Password<input type="password" required minLength="6" value={f.password} onChange={set('password')} /></label>
      {isReg && (
        <label>I want to<select value={f.role} onChange={set('role')}>
          <option value="attendee">Find and join events</option>
          <option value="organizer">Host events</option>
        </select></label>
      )}
      <button>{isReg ? 'Sign up' : 'Log in'}</button>
      <p className="muted">{isReg ? <>Have an account? <Link to="/login">Log in</Link></> : <>New here? <Link to="/register">Sign up</Link></>}</p>
    </form>
  );
}
