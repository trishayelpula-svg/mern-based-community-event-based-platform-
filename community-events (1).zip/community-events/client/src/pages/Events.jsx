import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

export const CATEGORIES = ['Music', 'Sports', 'Workshop', 'Food', 'Cleanup', 'Other'];
export const fmt = (d) => new Date(d).toLocaleString([], { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export function EventRow({ ev }) {
  const d = new Date(ev.date);
  return (
    <Link to={`/events/${ev._id}`} className="row">
      <div className="stamp"><b>{d.getDate()}</b><span>{d.toLocaleString([], { month: 'short' })}</span></div>
      <div className="grow">
        <h3>{ev.title}</h3>
        <p className="muted">{fmt(ev.date)} at {ev.venue.name}</p>
      </div>
      <div className="meta">
        <span className="tag">{ev.category}</span>
        <span className="muted">{ev.participants.length}/{ev.capacity} going</span>
      </div>
    </Link>
  );
}

export default function Events() {
  const [events, setEvents] = useState(null);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [upcoming, setUpcoming] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const q = new URLSearchParams({ search, category, upcoming });
    api('/events?' + q).then(setEvents).catch((e) => setError(e.message));
  }, [search, category, upcoming]);

  return (
    <>
      <section className="hero">
        <h1>What's happening on your street this week</h1>
        <p>Find a class, a cleanup, a gig. Or host one yourself.</p>
      </section>
      <div className="filters">
        <input placeholder="Search by title or venue" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          {['All', ...CATEGORIES].map((c) => <option key={c}>{c}</option>)}
        </select>
        <label className="check"><input type="checkbox" checked={upcoming} onChange={(e) => setUpcoming(e.target.checked)} /> Upcoming only</label>
      </div>
      {error && <p className="error">{error}</p>}
      {!events && !error && <p className="muted">Loading events…</p>}
      {events?.length === 0 && <p className="empty">No events match. Clear the filters, or host the first one.</p>}
      <div className="list">{events?.map((ev) => <EventRow key={ev._id} ev={ev} />)}</div>
    </>
  );
}
