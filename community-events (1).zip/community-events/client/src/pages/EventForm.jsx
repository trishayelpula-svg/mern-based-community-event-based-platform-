import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { CATEGORIES } from './Events.jsx';

const blank = { title: '', description: '', category: 'Other', date: '', venueName: '', venueAddress: '', capacity: 50 };

export default function EventForm() {
  const { id } = useParams(); // present => edit mode
  const nav = useNavigate();
  const [f, setF] = useState(blank);
  const [error, setError] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  useEffect(() => {
    if (!id) return;
    api(`/events/${id}`).then((e) => setF({
      title: e.title, description: e.description, category: e.category,
      date: new Date(e.date).toISOString().slice(0, 16),
      venueName: e.venue.name, venueAddress: e.venue.address, capacity: e.capacity,
    })).catch((e) => setError(e.message));
  }, [id]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const body = { title: f.title, description: f.description, category: f.category, date: f.date,
        capacity: Number(f.capacity), venue: { name: f.venueName, address: f.venueAddress } };
      const saved = await api(id ? `/events/${id}` : '/events', { method: id ? 'PUT' : 'POST', body });
      nav(`/events/${saved._id}`);
    } catch (err) { setError(err.message); }
  };

  return (
    <form className="form" onSubmit={submit}>
      <h1>{id ? 'Edit event' : 'Host an event'}</h1>
      {error && <p className="error">{error}</p>}
      <label>Title<input required value={f.title} onChange={set('title')} /></label>
      <label>Description<textarea required rows="4" value={f.description} onChange={set('description')} /></label>
      <div className="two">
        <label>Category<select value={f.category} onChange={set('category')}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></label>
        <label>Date and time<input type="datetime-local" required value={f.date} onChange={set('date')} /></label>
      </div>
      <div className="two">
        <label>Venue name<input required value={f.venueName} onChange={set('venueName')} /></label>
        <label>Address<input value={f.venueAddress} onChange={set('venueAddress')} /></label>
      </div>
      <label>Capacity<input type="number" min="1" value={f.capacity} onChange={set('capacity')} /></label>
      <button>{id ? 'Save changes' : 'Publish event'}</button>
    </form>
  );
}
