import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
// Proxy /api to Express so the browser sees one origin (no CORS fuss in dev)
export default defineConfig({ plugins: [react()], server: { proxy: { '/api': 'http://localhost:5000' } } });
