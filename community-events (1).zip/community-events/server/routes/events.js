const router = require('express').Router();
const Event = require('../models/Event');
const { protect, allow } = require('../middleware/auth');

const populate = (q) => q.populate('organizer', 'name email').populate('participants', 'name');
const canManage = (user, ev) => user.role === 'admin' || String(ev.organizer._id || ev.organizer) === String(user._id);

// READ (public): list with search, category and upcoming filters
router.get('/', async (req, res, next) => {
  try {
    const { search, category, upcoming } = req.query;
    const filter = {};
    if (search) filter.$or = [{ title: new RegExp(search, 'i') }, { 'venue.name': new RegExp(search, 'i') }];
    if (category && category !== 'All') filter.category = category;
    if (upcoming === 'true') filter.date = { $gte: new Date() };
    res.json(await populate(Event.find(filter).sort({ date: 1 })));
  } catch (e) { next(e); }
});

// Dashboard data (must be declared before '/:id')
router.get('/mine/organized', protect, async (req, res, next) => {
  try { res.json(await populate(Event.find({ organizer: req.user._id }).sort({ date: 1 }))); } catch (e) { next(e); }
});
router.get('/mine/joined', protect, async (req, res, next) => {
  try { res.json(await populate(Event.find({ participants: req.user._id }).sort({ date: 1 }))); } catch (e) { next(e); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const ev = await populate(Event.findById(req.params.id));
    if (!ev) return res.status(404).json({ message: 'Event not found' });
    res.json(ev);
  } catch (e) { next(e); }
});

// CREATE (organizer/admin only)
router.post('/', protect, allow('organizer', 'admin'), async (req, res, next) => {
  try {
    const { title, description, category, date, venue, capacity } = req.body;
    const ev = await Event.create({ title, description, category, date, venue, capacity, organizer: req.user._id });
    res.status(201).json(ev);
  } catch (e) { next(e); }
});

// UPDATE (owner or admin)
router.put('/:id', protect, async (req, res, next) => {
  try {
    const ev = await Event.findById(req.params.id);
    if (!ev) return res.status(404).json({ message: 'Event not found' });
    if (!canManage(req.user, ev)) return res.status(403).json({ message: 'Only the organizer can edit this event' });
    ['title', 'description', 'category', 'date', 'venue', 'capacity'].forEach((k) => {
      if (req.body[k] !== undefined) ev[k] = req.body[k];
    });
    res.json(await ev.save());
  } catch (e) { next(e); }
});

// DELETE (owner or admin)
router.delete('/:id', protect, async (req, res, next) => {
  try {
    const ev = await Event.findById(req.params.id);
    if (!ev) return res.status(404).json({ message: 'Event not found' });
    if (!canManage(req.user, ev)) return res.status(403).json({ message: 'Only the organizer can delete this event' });
    await ev.deleteOne();
    res.json({ message: 'Event deleted' });
  } catch (e) { next(e); }
});

// JOIN / LEAVE (any logged-in user). $addToSet prevents duplicates.
router.post('/:id/join', protect, async (req, res, next) => {
  try {
    const ev = await Event.findById(req.params.id);
    if (!ev) return res.status(404).json({ message: 'Event not found' });
    if (ev.participants.length >= ev.capacity && !ev.participants.includes(req.user._id))
      return res.status(400).json({ message: 'This event is full' });
    await Event.updateOne({ _id: ev._id }, { $addToSet: { participants: req.user._id } });
    res.json(await populate(Event.findById(ev._id)));
  } catch (e) { next(e); }
});
router.post('/:id/leave', protect, async (req, res, next) => {
  try {
    await Event.updateOne({ _id: req.params.id }, { $pull: { participants: req.user._id } });
    res.json(await populate(Event.findById(req.params.id)));
  } catch (e) { next(e); }
});

module.exports = router;
