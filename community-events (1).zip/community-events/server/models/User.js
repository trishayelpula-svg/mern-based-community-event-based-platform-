const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, minlength: 6 }, // stored as bcrypt hash
  role: { type: String, enum: ['attendee', 'organizer', 'admin'], default: 'attendee' },
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
