const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, required: true },
  category: { type: String, enum: ['Music', 'Sports', 'Workshop', 'Food', 'Cleanup', 'Other'], default: 'Other' },
  date: { type: Date, required: true },
  venue: {
    name: { type: String, required: true },
    address: { type: String, default: '' },
  },
  capacity: { type: Number, default: 50, min: 1 },
  organizer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
}, { timestamps: true });

eventSchema.index({ title: 'text', description: 'text' });

module.exports = mongoose.model('Event', eventSchema);
