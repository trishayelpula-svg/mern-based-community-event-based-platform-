// Run once: node seed.js  -> creates demo users and events
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Event = require('./models/Event');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User.deleteMany({}), Event.deleteMany({})]);
  const pw = await bcrypt.hash('password123', 10);
  const [admin, org, att] = await User.create([
    { name: 'Admin Anu', email: 'admin@demo.com', password: pw, role: 'admin' },
    { name: 'Organizer Ravi', email: 'organizer@demo.com', password: pw, role: 'organizer' },
    { name: 'Attendee Sara', email: 'attendee@demo.com', password: pw, role: 'attendee' },
  ]);
  const day = 864e5;
  await Event.create([
    { title: 'Lake Cleanup Morning', description: 'Gloves and bags provided. Bring water.', category: 'Cleanup', date: Date.now() + 3 * day, venue: { name: 'Hussain Sagar North Gate', address: 'Hyderabad' }, capacity: 40, organizer: org._id, participants: [att._id] },
    { title: 'Terrace Acoustic Night', description: 'Open mic for local musicians.', category: 'Music', date: Date.now() + 6 * day, venue: { name: 'Community Hall', address: 'Road No. 5' }, capacity: 60, organizer: org._id },
    { title: 'Weekend Pottery Workshop', description: 'Beginner friendly. Clay included.', category: 'Workshop', date: Date.now() + 9 * day, venue: { name: 'Studio 12' }, capacity: 12, organizer: admin._id },
  ]);
  console.log('Seeded. Logins: admin@demo.com / organizer@demo.com / attendee@demo.com  (password123)');
  process.exit(0);
})();
