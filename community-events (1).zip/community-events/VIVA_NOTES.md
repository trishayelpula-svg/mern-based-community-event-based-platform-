# Viva Notes – Porchlight Community Event Platform

## 1. One-minute pitch
Porchlight lets neighbours discover local events and lets organizers create and manage them. Built on MERN:
MongoDB stores events, users, venues and participants; Express + Node expose a REST API; React gives the UI.
Login uses JWT, and three roles (attendee, organizer, admin) control who can do what.

## 2. Architecture
Browser (React, Vite) --JSON over HTTP--> Express API --Mongoose--> MongoDB
- Vite dev server proxies /api to port 5000, so no CORS problems in development.
- Stateless API: every protected request carries `Authorization: Bearer <JWT>`.

## 3. Data model
- **User**: name, email (unique), password (bcrypt hash), role.
- **Event**: title, description, category, date, venue {name, address}, capacity,
  organizer (ref User), participants [ref User].
- Why references, not embedding? Users exist independently of events, and `populate()` joins names when needed.
  Venue is embedded because it belongs to exactly one event and is always read with it.
- A text index on title/description supports searching.

## 4. CRUD mapping
| Operation | Where |
|---|---|
| Create | POST /events (EventForm.jsx) |
| Read | GET /events, /events/:id (Events.jsx, EventDetail.jsx) |
| Update | PUT /events/:id (EventForm.jsx in edit mode); join/leave updates participants |
| Delete | DELETE /events/:id (EventDetail.jsx) |

## 5. Authentication and authorization
- Register: password hashed with bcrypt (10 salt rounds), never stored in plain text.
- Login: compare hash, issue JWT valid for 7 days, signed with JWT_SECRET.
- `protect` middleware verifies the token and loads req.user. `allow(...roles)` checks role.
- Ownership check in PUT/DELETE: organizer of that event, or admin.
- Admins cannot self-register; the register route ignores any role other than organizer/attendee (prevents privilege escalation).
- Frontend `Guard` component hides pages, **but the real enforcement is on the server**. Frontend checks are only UX.

## 6. Key code to be ready to explain
- **Join without duplicates**: `$addToSet` is atomic and ignores existing members; `$pull` removes on leave.
- **Capacity check**: compare participants.length with capacity before join.
- **Filters**: query string built into a Mongo filter (regex for search, `$gte: new Date()` for upcoming).
- **Route order**: `/mine/organized` is declared before `/:id`, otherwise Express would treat "mine" as an id.
- **Error handling**: one central middleware turns Mongoose ValidationError into 400 and CastError into 400.

## 7. Likely viva questions and short answers
1. **Why MongoDB?** Flexible documents suit events with nested venue and variable participant lists; Mongoose adds validation.
2. **JWT vs sessions?** JWT is stateless, so the API scales without a session store; trade-off is that revoking a token before expiry is harder.
3. **Where is the token stored?** localStorage here for simplicity. Safer in production: httpOnly cookie, which resists XSS theft.
4. **How is password security handled?** bcrypt hashing with salt; minimum length validation.
5. **What stops an attendee from creating events by calling the API directly?** `allow('organizer','admin')` on the route returns 403.
6. **What is `populate`?** Mongoose replaces ObjectId references with the referenced documents (organizer name, participant names).
7. **Why a proxy in Vite?** The browser sees one origin, so no CORS config is needed in development.
8. **React Context?** AuthContext shares user and login/logout across components without prop drilling.
9. **What would you add next?** Pagination, image upload, email reminders, map view, rate limiting, input sanitising of the regex search, tests (Jest + Supertest).
10. **Known limitations (say them honestly)**: search regex is not escaped, no pagination, token in localStorage, no automated tests, capacity check has a small race window under heavy concurrency (fix: conditional atomic update).

## 8. Demo script (3 minutes)
1. Open home page, filter by category, search a venue.
2. Sign up as attendee, join an event, see it on "My events".
3. Log out, log in as organizer, host a new event, edit it.
4. Show an attendee gets no "Host an event" link, and mention the API returns 403 anyway.
5. Log in as admin and delete someone else's event.
6. Open the network tab to show the JWT header and Mongo Compass to show the documents.

## 9. If the project title is "Neighborhood Issue Tracker"
Same architecture, rename entities: Event -> Issue (title, description, category e.g. Pothole/Streetlight/Garbage,
status Open/In progress/Resolved, location, reportedBy), participants -> upvotes/comments, organizer -> assignedTo (municipal role).
Roles: resident (report, upvote), staff (update status), admin (manage all).
