# Porchlight – Community Event Platform (MERN)

## Run it
Prerequisites: Node 18+, MongoDB running locally (or an Atlas URI).

    # Terminal 1 – API
    cd server
    cp .env.example .env        # edit JWT_SECRET / MONGO_URI if needed
    npm install
    node seed.js                # optional demo data
    npm run dev                 # http://localhost:5000

    # Terminal 2 – UI
    cd client
    npm install
    npm run dev                 # http://localhost:5173

Demo logins (after seeding, password `password123`):
admin@demo.com, organizer@demo.com, attendee@demo.com

## REST API
| Method | Endpoint | Access |
|---|---|---|
| POST | /api/auth/register | public |
| POST | /api/auth/login | public |
| GET | /api/auth/me | logged in |
| GET | /api/events?search=&category=&upcoming= | public |
| GET | /api/events/:id | public |
| POST | /api/events | organizer, admin |
| PUT | /api/events/:id | owner, admin |
| DELETE | /api/events/:id | owner, admin |
| POST | /api/events/:id/join, /leave | logged in |
| GET | /api/events/mine/organized, /mine/joined | logged in |

## Folder map
    server/  models (User, Event) · routes (auth, events) · middleware/auth.js · server.js · seed.js
    client/src/  api.js · AuthContext.jsx · App.jsx · pages/ (Events, EventDetail, EventForm, Dashboard, Auth)
